/**
 * 
 */
package snippet;

/**
 * @author ssi248
 *
 */
public class Snippet {
	/**
	 * 
	 */
	public static void main(String[] args) {
		E:\Workspace\USAF
	}
}

