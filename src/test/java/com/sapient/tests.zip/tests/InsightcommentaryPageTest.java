/**
 * 
 *//*
package com.sapient.tests;

import org.testng.annotations.Test;

import com.sapient.core.CustomAssertion;
import com.sapient.core.SeleniumTestPlan;
import com.sapient.webpage.InsightcommentaryPage;

*//**
 * @author ssi248
 *
 *//*
public class InsightcommentaryPageTest extends SeleniumTestPlan {
	
	String[] layoutTags ={"desktop"};
	 
	 @Test(description="Verify the UI of Insight commentary Page")
	 public void galenUiTest() throws Exception
	 {

		 InsightcommentaryPage insight= new InsightcommentaryPage(true);
	 	CustomAssertion.assertTrue(insight.testPageLayout(layoutTags), "[Assert Fail]:Pixel are not correct");
	 }

}
*/