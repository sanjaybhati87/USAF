/**
 * 
 */
package com.sapient.webpage;

import org.openqa.selenium.WebDriver;

/**
 * @author ssi248
 *
 */
public class DistinctiveApproachToEquityPage extends WebBasePage {

	/**
	 * @param driver
	 * @param pagename
	 */
	public DistinctiveApproachToEquityPage(WebDriver driver) {
		super(driver, "DistinctiveApproachToEquityPage");
		// TODO Auto-generated constructor stub
	}

}
