/**
 * 
 */
package com.sapient.webpage;

import org.openqa.selenium.WebDriver;

/**
 * @author ssi248
 *
 */
public class FundDetailsPage extends WebBasePage {

	/**
	 * @param driver
	 * @param pagename
	 */
	public FundDetailsPage(WebDriver driver) {
		super(driver, "FundDetailsPage");
		// TODO Auto-generated constructor stub
	}

}
